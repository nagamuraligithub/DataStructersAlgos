package com.example;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;

public class SortingAlgorithms extends JFrame {

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
            	SortingAlgorithms frame = new SortingAlgorithms();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public SortingAlgorithms() {
        setTitle("Sorting Algorithms");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen and resizable
        setMinimumSize(new Dimension(600, 400));

        JPanel contentPane = new JPanel(new GridBagLayout());
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        Font buttonFont = new Font("Arial", Font.BOLD, 20);
        Dimension buttonSize = new Dimension(250, 50);

        JButton btnBubbleSorting = createResponsiveButton("Bubble Sort", buttonFont, buttonSize);
        btnBubbleSorting.addActionListener(e -> new BubbleSortAlgo().setVisible(true));
        gbc.gridy = 0;
        contentPane.add(btnBubbleSorting, gbc);

        JButton btnSelectionSorting = createResponsiveButton("Selection Sort", buttonFont, buttonSize);
        btnSelectionSorting.addActionListener(e -> new SelectionSortAlgo().setVisible(true));
        gbc.gridy = 1;
        contentPane.add(btnSelectionSorting, gbc);

        JButton btnInsertionSort = createResponsiveButton("Insertion Sort", buttonFont, buttonSize);
        btnInsertionSort.addActionListener(e -> new InsertionSortAlgo().setVisible(true));
        gbc.gridy = 2;
        contentPane.add(btnInsertionSort, gbc);
    }

    private JButton createResponsiveButton(String text, Font font, Dimension size) {
        JButton button = new JButton(text);
        button.setFont(font);
        button.setPreferredSize(size);
        button.setMinimumSize(size);
        button.setFocusPainted(false);
        return button;
    }
}
